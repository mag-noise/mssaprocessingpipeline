% MSSAMex.m Help file for MSSAMex MEX-file.
%  MSSAMex - Signal Processing for 2 signals
% 
%  The calling syntax is:
% 
% 		[min, mout, flags, win, wout] = ...
%           MSSAMex(inboard, outboard, timeseries, ...
%               alpha, segment_size, window_size);
% 
